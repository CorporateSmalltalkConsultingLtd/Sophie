#!/bin/sh
APP=`dirname $0`
EXE="$APP/Contents/Linux686"
RES="$APP/Contents/Resources"

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:$EXE/cairo
echo $LD_LIBRARY_PATH

exec "$EXE/squeak" -plugins "$EXE" \
	-encoding UTF-8 \
	-vm-display-X11 -swapbtn  \
	"$RES/sophie.image"
